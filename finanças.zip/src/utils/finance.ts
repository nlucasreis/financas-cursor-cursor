import { Expense, MonthSummary, Category } from '../types';

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value || 0);
}

export function formatDateBR(dateStr: string): string {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-');
  if (!year || !month || !day) return dateStr;
  return `${day}/${month}/${year}`;
}

export function formatShortDateBR(dateStr: string): string {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-');
  if (!year || !month || !day) return dateStr;
  const months = ['jan.', 'fev.', 'mar.', 'abr.', 'mai.', 'jun.', 'jul.', 'ago.', 'set.', 'out.', 'nov.', 'dez.'];
  const monthIdx = parseInt(month, 10) - 1;
  const monthName = months[monthIdx] || '';
  return `${day} de ${monthName}`;
}

export function getMonthYearLabel(monthYear: string): string {
  if (!monthYear) return '';
  const [year, month] = monthYear.split('-');
  const monthNum = parseInt(month, 10);
  const monthNames = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];
  return `${monthNames[monthNum - 1] || ''} de ${year}`;
}

export function getRelativeMonthYear(currentMonthYear: string, offset: number): string {
  const [year, month] = currentMonthYear.split('-').map(Number);
  const date = new Date(year, month - 1 + offset, 1);
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  return `${y}-${m}`;
}

export function calculateMonthSummary(
  expenses: Expense[],
  categoriesMap?: Record<string, Category>
): MonthSummary {
  let totalAmount = 0;
  let totalPaid = 0;
  let totalPending = 0;
  let paidCount = 0;

  let essentialTotal = 0;
  let lifestyleTotal = 0;
  let otherTotal = 0;

  expenses.forEach((exp) => {
    const amt = exp.amount || 0;
    totalAmount += amt;

    if (exp.status === 'paid') {
      totalPaid += amt;
      paidCount += 1;
    } else {
      totalPending += amt;
    }

    if (categoriesMap && exp.categoryId) {
      const cat = categoriesMap[exp.categoryId];
      if (cat) {
        if (cat.type === 'essential' || cat.type === 'utility') {
          essentialTotal += amt;
        } else if (cat.type === 'lifestyle') {
          lifestyleTotal += amt;
        } else {
          otherTotal += amt;
        }
      } else {
        otherTotal += amt;
      }
    }
  });

  const percentPaid = totalAmount > 0 ? Math.round((totalPaid / totalAmount) * 100) : 0;

  return {
    totalAmount,
    totalPaid,
    totalPending,
    paidCount,
    totalCount: expenses.length,
    percentPaid,
    essentialTotal,
    lifestyleTotal,
    otherTotal,
  };
}

