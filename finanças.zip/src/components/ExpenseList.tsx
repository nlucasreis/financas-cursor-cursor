import React from 'react';
import { Expense, Category } from '../types';
import { formatShortDateBR } from '../utils/finance';
import { Tag, Plus } from 'lucide-react';

export const SquareRecycleIcon = ({ className = "w-3.5 h-3.5" }: { className?: string }) => (
  <svg
    className={className}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <rect x="3" y="3" width="18" height="18" rx="4" />
    <path d="M7 9h4V5" />
    <path d="M11 9A4 4 0 0 1 15 13" />
    <path d="M17 15h-4v4" />
    <path d="M13 15A4 4 0 0 1 9 11" />
  </svg>
);

interface ExpenseListProps {
  expenses: Expense[];
  categories: Category[];
  selectedCategory?: string;
  onEditExpense: (expense: Expense) => void;
  onDeleteExpense: (expenseId: string) => void;
  onDuplicateExpense: (expense: Expense) => void;
  onToggleStatus: (expenseId: string) => void;
  onOpenAddModal: () => void;
}

export const ExpenseList: React.FC<ExpenseListProps> = ({
  expenses,
  categories,
  selectedCategory = 'all',
  onEditExpense,
  onOpenAddModal,
}) => {
  const getCategory = (catId: string) => {
    return (
      categories.find((c) => c.id === catId) || {
        id: 'cat-other',
        name: 'Outros',
        iconName: 'Tag',
        color: 'text-slate-600',
        bgColor: 'bg-slate-50 border-slate-200',
        type: 'other' as const,
      }
    );
  };

  // Filtered expenses logic
  const filteredExpenses = expenses.filter((exp) => {
    return selectedCategory === 'all' || exp.categoryId === selectedCategory;
  });

  return (
    <div className="bg-white dark:bg-zinc-800/80 rounded-2xl border border-slate-200/80 dark:border-zinc-700/60 shadow-2xs overflow-hidden transition-colors">
      {filteredExpenses.length === 0 ? (
        <div className="p-8 sm:p-10 text-center flex flex-col items-center justify-center space-y-3">
          <div className="w-10 h-10 rounded-2xl bg-slate-100 dark:bg-zinc-700 flex items-center justify-center text-slate-400 dark:text-slate-300">
            <Tag className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
              Nenhuma transação encontrada
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm">
              {expenses.length === 0
                ? 'Nenhuma conta cadastrada para este mês. Adicione sua primeira conta no botão abaixo!'
                : 'Nenhum lançamento encontrado nesta categoria.'}
            </p>
          </div>
          {expenses.length === 0 && (
            <button
              type="button"
              onClick={onOpenAddModal}
              className="mt-2 flex items-center space-x-2 bg-white hover:bg-slate-100 text-zinc-700 hover:text-zinc-900 border border-slate-200 dark:border-zinc-700 px-4 py-2 rounded-xl text-xs font-semibold shadow-xs transition-all active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Primeira Conta</span>
            </button>
          )}
        </div>
      ) : (
        <div className="divide-y divide-slate-100 dark:divide-zinc-700/50">
          {filteredExpenses.map((expense) => {
            const category = getCategory(expense.categoryId);

            const formattedAmount = expense.amount.toLocaleString('pt-BR', {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            });

            return (
              <div
                key={expense.id}
                onClick={() => onEditExpense(expense)}
                className="p-2.5 sm:px-4 sm:py-2.5 hover:bg-slate-50/80 dark:hover:bg-zinc-700/40 transition-colors flex items-center justify-between cursor-pointer group"
              >
                {/* Left Side: Title & Subtitle */}
                <div className="space-y-0.5">
                  <div className="font-semibold text-xs sm:text-sm text-slate-900 dark:text-slate-100 tracking-tight">
                    {expense.title}
                  </div>
                  <div className="text-[11px] sm:text-xs text-slate-400 dark:text-slate-400 font-normal">
                    {category.name}
                  </div>
                </div>

                {/* Right Side: Value & Date */}
                <div className="text-right space-y-0.5">
                  <div className="font-semibold text-xs sm:text-sm text-slate-900 dark:text-slate-100 tracking-tight">
                    -R$ {formattedAmount}
                  </div>
                  <div className="text-[11px] sm:text-xs text-slate-400 dark:text-slate-400 font-normal">
                    {formatShortDateBR(expense.dueDate)}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
