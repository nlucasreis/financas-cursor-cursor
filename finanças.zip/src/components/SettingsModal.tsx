import React from 'react';
import { X, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenRecurring: () => void;
  onOpenExportImport: () => void;
  onResetDemo: () => void;
  monthlyBudget: number;
  onUpdateBudget: (budget: number) => void;
  isDark?: boolean;
  onToggleTheme?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  onOpenRecurring,
  onOpenExportImport,
  onResetDemo,
  monthlyBudget,
  onUpdateBudget,
  isDark,
  onToggleTheme,
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/40 backdrop-blur-xs"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 8 }}
            transition={{ type: 'spring', stiffness: 400, damping: 30 }}
            className="relative bg-white dark:bg-zinc-900 rounded-[28px] max-w-md w-full p-6 shadow-2xl border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-zinc-100 z-10 overflow-hidden transition-colors"
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-zinc-100 dark:border-zinc-800">
              <h2 className="text-base font-bold text-zinc-900 dark:text-white tracking-tight">
                Ajustes
              </h2>
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content Body */}
            <div className="py-4 space-y-2.5">
              {/* Theme Preference Toggle */}
              <button
                type="button"
                onClick={onToggleTheme}
                className="w-full bg-zinc-50 dark:bg-zinc-800/60 p-3.5 rounded-2xl border border-zinc-200/80 dark:border-zinc-700/60 flex items-center justify-between text-left transition-all hover:bg-zinc-100/80 dark:hover:bg-zinc-800 cursor-pointer"
              >
                <div>
                  <p className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                    Aparência do App
                  </p>
                  <p className="text-[11px] text-zinc-400 mt-0.5">
                    {isDark ? 'Modo Escuro ativado' : 'Modo Claro ativado'}
                  </p>
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider bg-zinc-200/80 dark:bg-zinc-700 text-zinc-700 dark:text-zinc-300 px-2.5 py-1 rounded-full">
                  {isDark ? 'Escuro' : 'Claro'}
                </span>
              </button>

              {/* Monthly Budget Input */}
              <div className="bg-zinc-50 dark:bg-zinc-800/60 p-3.5 rounded-2xl border border-zinc-200/80 dark:border-zinc-700/60 space-y-1.5">
                <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">
                  Orçamento Mensal
                </label>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-zinc-400">R$</span>
                  <input
                    type="number"
                    value={monthlyBudget || ''}
                    onChange={(e) => onUpdateBudget(Number(e.target.value) || 0)}
                    placeholder="0,00"
                    className="w-full bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-700 rounded-xl px-3 py-2 text-sm font-semibold text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-zinc-800 dark:focus:ring-zinc-400 transition-all"
                  />
                </div>
              </div>

              {/* Recorrentes */}
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenRecurring();
                }}
                className="w-full flex items-center justify-between p-3.5 bg-zinc-50/70 dark:bg-zinc-800/50 hover:bg-zinc-100/80 dark:hover:bg-zinc-800 border border-zinc-200/80 dark:border-zinc-700/60 rounded-2xl text-left transition-all cursor-pointer group"
              >
                <div>
                  <p className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                    Contas Fixas e Recorrentes
                  </p>
                  <p className="text-[11px] text-zinc-400 mt-0.5">
                    Gerenciar cobranças mensais automáticas
                  </p>
                </div>
                <ChevronRight className="w-4 h-4 text-zinc-300 dark:text-zinc-500 group-hover:text-zinc-600 dark:group-hover:text-zinc-300 transition-colors shrink-0 ml-2" />
              </button>

              {/* Backup */}
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenExportImport();
                }}
                className="w-full flex items-center justify-between p-3.5 bg-zinc-50/70 dark:bg-zinc-800/50 hover:bg-zinc-100/80 dark:hover:bg-zinc-800 border border-zinc-200/80 dark:border-zinc-700/60 rounded-2xl text-left transition-all cursor-pointer group"
              >
                <div>
                  <p className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                    Exportar e Importar
                  </p>
                  <p className="text-[11px] text-zinc-400 mt-0.5">
                    Backup ou restauração em JSON / CSV
                  </p>
                </div>
                <ChevronRight className="w-4 h-4 text-zinc-300 dark:text-zinc-500 group-hover:text-zinc-600 dark:group-hover:text-zinc-300 transition-colors shrink-0 ml-2" />
              </button>

              {/* Demo Reset */}
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onResetDemo();
                }}
                className="w-full flex items-center justify-between p-3.5 bg-zinc-50/70 dark:bg-zinc-800/50 hover:bg-zinc-100/80 dark:hover:bg-zinc-800 border border-zinc-200/80 dark:border-zinc-700/60 rounded-2xl text-left transition-all cursor-pointer group"
              >
                <div>
                  <p className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                    Restaurar Dados Exemplo
                  </p>
                  <p className="text-[11px] text-zinc-400 mt-0.5">
                    Recarregar transações de demonstração
                  </p>
                </div>
                <ChevronRight className="w-4 h-4 text-zinc-300 dark:text-zinc-500 group-hover:text-zinc-600 dark:group-hover:text-zinc-300 transition-colors shrink-0 ml-2" />
              </button>
            </div>

            {/* Footer */}
            <div className="pt-2">
              <button
                type="button"
                onClick={onClose}
                className="w-full py-2.5 bg-zinc-800 hover:bg-zinc-900 text-white text-xs font-semibold rounded-2xl transition-all active:scale-[0.99] cursor-pointer"
              >
                Concluído
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

